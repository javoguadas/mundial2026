// ============================================================
//  auth.js — Manejo de sesión y autenticación
// ============================================================

function getSession() {
  const s = localStorage.getItem('session_mundial');
  return s ? JSON.parse(s) : null;
}

function setSession(usuario) {
  localStorage.setItem('session_mundial', JSON.stringify(usuario));
}

function cerrarSesion() {
  localStorage.removeItem('session_mundial');
  window.location.href = getBasePath() + 'index.html';
}

function getBasePath() {
  // Detectar si estamos en pages/ o en la raíz
  return window.location.pathname.includes('/pages/') ? '../' : '';
}

function esAdmin() {
  const s = getSession();
  return s && s.esAdmin;
}

function requiereLogin() {
  if (!getSession()) {
    window.location.href = getBasePath() + 'pages/login.html';
    return false;
  }
  return true;
}

function requiereAdmin() {
  if (!esAdmin()) {
    alert('Acceso solo para administrador.');
    window.location.href = getBasePath() + 'index.html';
    return false;
  }
  return true;
}

// Actualizar navbar dinámicamente
document.addEventListener('DOMContentLoaded', () => {
  const area = document.getElementById('authArea');
  if (!area) return;

  const session = getSession();
  if (session) {
    area.innerHTML = `
      <span style="color:var(--text-dim);font-size:.8rem;margin-right:.5rem">
        ${session.esAdmin ? '🔑' : '👤'} ${session.nombre}
      </span>
      ${session.esAdmin ? `<a href="${getBasePath()}pages/admin.html" class="btn-nav" style="margin-right:.5rem">Admin</a>` : ''}
      <button onclick="cerrarSesion()" class="btn-nav" style="background:transparent;border:1px solid #333;color:var(--text-dim)">Salir</button>
    `;
  }
});

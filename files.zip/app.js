// ============================================================
//  MUNDIAL 2026 — app.js
//  Datos del torneo y funciones globales
// ============================================================

// ── DATOS DE EQUIPOS — Rankings FIFA oficiales + estadísticas históricas ──
// Ranking FIFA actualizado (fuente oficial)
// goles/tarjetas/offsides = promedio por partido en últimos 10 partidos oficiales
const EQUIPOS_STATS = {
  "España":           { goles:2.3, tarjetas:1.2, offsides:1.7, ranking:1  },
  "Argentina":        { goles:2.2, tarjetas:1.5, offsides:1.6, ranking:2  },
  "Francia":          { goles:2.0, tarjetas:1.4, offsides:1.5, ranking:3  },
  "Inglaterra":       { goles:1.9, tarjetas:1.4, offsides:1.7, ranking:4  },
  "Brasil":           { goles:2.1, tarjetas:1.3, offsides:1.2, ranking:5  },
  "Portugal":         { goles:2.2, tarjetas:1.5, offsides:1.7, ranking:6  },
  "Holanda":          { goles:1.9, tarjetas:1.4, offsides:1.7, ranking:7  },
  "Marruecos":        { goles:1.5, tarjetas:1.7, offsides:1.3, ranking:8  },
  "Bélgica":          { goles:1.8, tarjetas:1.4, offsides:1.5, ranking:9  },
  "Alemania":         { goles:2.0, tarjetas:1.4, offsides:1.8, ranking:10 },
  "Croacia":          { goles:1.6, tarjetas:1.4, offsides:1.5, ranking:11 },
  "Senegal":          { goles:1.8, tarjetas:1.5, offsides:1.4, ranking:12 },
  "Colombia":         { goles:1.7, tarjetas:1.6, offsides:1.5, ranking:14 },
  "EEUU":             { goles:1.8, tarjetas:1.5, offsides:1.6, ranking:15 },
  "México":           { goles:1.8, tarjetas:1.8, offsides:2.1, ranking:16 },
  "Uruguay":          { goles:1.7, tarjetas:1.5, offsides:1.3, ranking:17 },
  "Suiza":            { goles:1.7, tarjetas:1.3, offsides:1.4, ranking:18 },
  "Japón":            { goles:1.6, tarjetas:1.2, offsides:1.5, ranking:19 },
  "Irán":             { goles:1.3, tarjetas:1.9, offsides:1.3, ranking:20 },
  "Corea del Sur":    { goles:1.6, tarjetas:1.5, offsides:1.8, ranking:22 },
  "Ecuador":          { goles:1.4, tarjetas:1.6, offsides:1.5, ranking:23 },
  "Austria":          { goles:1.7, tarjetas:1.5, offsides:1.6, ranking:24 },
  "Australia":        { goles:1.3, tarjetas:1.5, offsides:1.4, ranking:27 },
  "Argelia":          { goles:1.4, tarjetas:1.8, offsides:1.4, ranking:28 },
  "Canadá":           { goles:1.5, tarjetas:1.4, offsides:1.6, ranking:29 },
  "Noruega":          { goles:1.8, tarjetas:1.3, offsides:1.9, ranking:32 },
  "Egipto":           { goles:1.4, tarjetas:1.7, offsides:1.4, ranking:31 },
  "Panamá":           { goles:1.2, tarjetas:1.9, offsides:1.2, ranking:33 },
  "Costa de Marfil":  { goles:1.5, tarjetas:1.7, offsides:1.4, ranking:37 },
  "Escocia":          { goles:1.4, tarjetas:1.6, offsides:1.7, ranking:38 },
  "Paraguay":         { goles:1.2, tarjetas:1.9, offsides:1.3, ranking:40 },
  "Túnez":            { goles:1.2, tarjetas:1.8, offsides:1.3, ranking:47 },
  "Uzbekistán":       { goles:1.1, tarjetas:1.7, offsides:1.3, ranking:52 },
  "Catar":            { goles:1.1, tarjetas:1.8, offsides:1.2, ranking:56 },
  "Sudáfrica":        { goles:1.2, tarjetas:1.9, offsides:1.5, ranking:60 },
  "Arabia Saudí":     { goles:1.3, tarjetas:1.8, offsides:1.4, ranking:61 },
  "Jordania":         { goles:1.0, tarjetas:1.8, offsides:1.1, ranking:64 },
  "Cabo Verde":       { goles:1.1, tarjetas:1.9, offsides:1.2, ranking:67 },
  "Ghana":            { goles:1.2, tarjetas:1.8, offsides:1.3, ranking:72 },
  "Curasao":          { goles:0.9, tarjetas:2.0, offsides:1.0, ranking:81 },
  "Haití":            { goles:0.8, tarjetas:2.1, offsides:1.1, ranking:83 },
  "Nueva Zelanda":    { goles:1.1, tarjetas:1.5, offsides:1.2, ranking:85 },
  // Play-offs (estimados según zona)
  "UEFA Play-Off A":  { goles:1.5, tarjetas:1.5, offsides:1.5, ranking:35 },
  "UEFA Play-Off B":  { goles:1.4, tarjetas:1.6, offsides:1.4, ranking:43 },
  "UEFA Play-Off C":  { goles:1.4, tarjetas:1.6, offsides:1.4, ranking:46 },
  "UEFA Play-Off D":  { goles:1.3, tarjetas:1.6, offsides:1.3, ranking:50 },
  "Fifa Play-Off 1":  { goles:1.3, tarjetas:1.7, offsides:1.3, ranking:55 },
  "Fifa Play-Off 2":  { goles:1.2, tarjetas:1.7, offsides:1.2, ranking:58 },
};

// ── CALENDARIO COMPLETO ────────────────────────────────────
const PARTIDOS = [
  // GRUPO A
  { id:1,  grupo:"A", local:"México",       visitante:"Sudáfrica",     fecha:"Jue 11 Jun", hora:"13:00", estado:"pendiente" },
  { id:2,  grupo:"A", local:"Corea del Sur",visitante:"UEFA Play-Off D",fecha:"Jue 11 Jun", hora:"20:00", estado:"pendiente" },
  { id:3,  grupo:"A", local:"UEFA Play-Off D",visitante:"Sudáfrica",   fecha:"Jue 18 Jun", hora:"10:00", estado:"pendiente" },
  { id:4,  grupo:"A", local:"México",       visitante:"Corea del Sur", fecha:"Jue 18 Jun", hora:"19:00", estado:"pendiente" },
  { id:5,  grupo:"A", local:"UEFA Play-Off D",visitante:"México",      fecha:"Mié 24 Jun", hora:"19:00", estado:"pendiente" },
  { id:6,  grupo:"A", local:"Sudáfrica",    visitante:"Corea del Sur", fecha:"Mié 24 Jun", hora:"19:00", estado:"pendiente" },

  // GRUPO B
  { id:7,  grupo:"B", local:"Canadá",       visitante:"UEFA Play-Off A",fecha:"Vie 12 Jun", hora:"13:00", estado:"pendiente" },
  { id:8,  grupo:"B", local:"Catar",        visitante:"Suiza",         fecha:"Sáb 13 Jun", hora:"13:00", estado:"pendiente" },
  { id:9,  grupo:"B", local:"Suiza",        visitante:"UEFA Play-Off A",fecha:"Jue 18 Jun", hora:"13:00", estado:"pendiente" },
  { id:10, grupo:"B", local:"Canadá",       visitante:"Catar",         fecha:"Jue 18 Jun", hora:"16:00", estado:"pendiente" },
  { id:11, grupo:"B", local:"Suiza",        visitante:"Canadá",        fecha:"Mié 24 Jun", hora:"13:00", estado:"pendiente" },
  { id:12, grupo:"B", local:"UEFA Play-Off A",visitante:"Catar",       fecha:"Mié 24 Jun", hora:"13:00", estado:"pendiente" },

  // GRUPO C
  { id:13, grupo:"C", local:"Brasil",       visitante:"Marruecos",     fecha:"Sáb 13 Jun", hora:"16:00", estado:"pendiente" },
  { id:14, grupo:"C", local:"Haití",        visitante:"Escocia",       fecha:"Sáb 13 Jun", hora:"19:00", estado:"pendiente" },
  { id:15, grupo:"C", local:"Escocia",      visitante:"Marruecos",     fecha:"Vie 19 Jun", hora:"16:00", estado:"pendiente" },
  { id:16, grupo:"C", local:"Brasil",       visitante:"Haití",         fecha:"Vie 19 Jun", hora:"19:00", estado:"pendiente" },
  { id:17, grupo:"C", local:"Escocia",      visitante:"Brasil",        fecha:"Mié 24 Jun", hora:"16:00", estado:"pendiente" },
  { id:18, grupo:"C", local:"Marruecos",    visitante:"Haití",         fecha:"Mié 24 Jun", hora:"16:00", estado:"pendiente" },

  // GRUPO D
  { id:19, grupo:"D", local:"EEUU",         visitante:"Paraguay",      fecha:"Vie 12 Jun", hora:"19:00", estado:"pendiente" },
  { id:20, grupo:"D", local:"Australia",    visitante:"UEFA Play-Off C",fecha:"Sáb 13 Jun", hora:"22:00", estado:"pendiente" },
  { id:21, grupo:"D", local:"EEUU",         visitante:"Australia",     fecha:"Vie 19 Jun", hora:"13:00", estado:"pendiente" },
  { id:22, grupo:"D", local:"UEFA Play-Off C",visitante:"Paraguay",    fecha:"Vie 19 Jun", hora:"22:00", estado:"pendiente" },
  { id:23, grupo:"D", local:"UEFA Play-Off C",visitante:"EEUU",        fecha:"Jue 25 Jun", hora:"20:00", estado:"pendiente" },
  { id:24, grupo:"D", local:"Paraguay",     visitante:"Australia",     fecha:"Jue 25 Jun", hora:"20:00", estado:"pendiente" },

  // GRUPO E
  { id:25, grupo:"E", local:"Alemania",     visitante:"Curasao",       fecha:"Dom 14 Jun", hora:"11:00", estado:"pendiente" },
  { id:26, grupo:"E", local:"Costa de Marfil",visitante:"Ecuador",     fecha:"Dom 14 Jun", hora:"17:00", estado:"pendiente" },
  { id:27, grupo:"E", local:"Alemania",     visitante:"Costa de Marfil",fecha:"Sáb 20 Jun", hora:"14:00", estado:"pendiente" },
  { id:28, grupo:"E", local:"Ecuador",      visitante:"Curasao",       fecha:"Sáb 20 Jun", hora:"18:00", estado:"pendiente" },
  { id:29, grupo:"E", local:"Curasao",      visitante:"Costa de Marfil",fecha:"Jue 25 Jun", hora:"14:00", estado:"pendiente" },
  { id:30, grupo:"E", local:"Ecuador",      visitante:"Alemania",      fecha:"Jue 25 Jun", hora:"14:00", estado:"pendiente" },

  // GRUPO F
  { id:31, grupo:"F", local:"Holanda",      visitante:"Japón",         fecha:"Dom 14 Jun", hora:"14:00", estado:"pendiente" },
  { id:32, grupo:"F", local:"UEFA Play-Off B",visitante:"Túnez",       fecha:"Dom 14 Jun", hora:"20:00", estado:"pendiente" },
  { id:33, grupo:"F", local:"Holanda",      visitante:"UEFA Play-Off B",fecha:"Sáb 20 Jun", hora:"11:00", estado:"pendiente" },
  { id:34, grupo:"F", local:"Túnez",        visitante:"Japón",         fecha:"Sáb 20 Jun", hora:"22:00", estado:"pendiente" },
  { id:35, grupo:"F", local:"Japón",        visitante:"UEFA Play-Off B",fecha:"Jue 25 Jun", hora:"17:00", estado:"pendiente" },
  { id:36, grupo:"F", local:"Túnez",        visitante:"Holanda",       fecha:"Jue 25 Jun", hora:"17:00", estado:"pendiente" },

  // GRUPO G
  { id:37, grupo:"G", local:"Bélgica",      visitante:"Egipto",        fecha:"Lun 15 Jun", hora:"13:00", estado:"pendiente" },
  { id:38, grupo:"G", local:"Irán",         visitante:"Nueva Zelanda", fecha:"Lun 15 Jun", hora:"19:00", estado:"pendiente" },
  { id:39, grupo:"G", local:"Bélgica",      visitante:"Irán",          fecha:"Dom 21 Jun", hora:"13:00", estado:"pendiente" },
  { id:40, grupo:"G", local:"Nueva Zelanda",visitante:"Egipto",        fecha:"Dom 21 Jun", hora:"19:00", estado:"pendiente" },
  { id:41, grupo:"G", local:"Egipto",       visitante:"Irán",          fecha:"Vie 26 Jun", hora:"21:00", estado:"pendiente" },
  { id:42, grupo:"G", local:"Nueva Zelanda",visitante:"Bélgica",       fecha:"Vie 26 Jun", hora:"21:00", estado:"pendiente" },

  // GRUPO H
  { id:43, grupo:"H", local:"España",       visitante:"Cabo Verde",    fecha:"Lun 15 Jun", hora:"10:00", estado:"pendiente" },
  { id:44, grupo:"H", local:"Arabia Saudí", visitante:"Uruguay",       fecha:"Lun 15 Jun", hora:"16:00", estado:"pendiente" },
  { id:45, grupo:"H", local:"España",       visitante:"Arabia Saudí",  fecha:"Dom 21 Jun", hora:"10:00", estado:"pendiente" },
  { id:46, grupo:"H", local:"Uruguay",      visitante:"Cabo Verde",    fecha:"Dom 21 Jun", hora:"16:00", estado:"pendiente" },
  { id:47, grupo:"H", local:"Uruguay",      visitante:"España",        fecha:"Vie 26 Jun", hora:"18:00", estado:"pendiente" },
  { id:48, grupo:"H", local:"Cabo Verde",   visitante:"Arabia Saudí",  fecha:"Vie 26 Jun", hora:"18:00", estado:"pendiente" },

  // GRUPO I
  { id:49, grupo:"I", local:"Francia",      visitante:"Senegal",       fecha:"Mar 16 Jun", hora:"13:00", estado:"pendiente" },
  { id:50, grupo:"I", local:"Fifa Play-Off 2",visitante:"Noruega",     fecha:"Mar 16 Jun", hora:"16:00", estado:"pendiente" },
  { id:51, grupo:"I", local:"Francia",      visitante:"Fifa Play-Off 2",fecha:"Lun 22 Jun", hora:"15:00", estado:"pendiente" },
  { id:52, grupo:"I", local:"Noruega",      visitante:"Senegal",       fecha:"Lun 22 Jun", hora:"18:00", estado:"pendiente" },
  { id:53, grupo:"I", local:"Noruega",      visitante:"Francia",       fecha:"Vie 26 Jun", hora:"13:00", estado:"pendiente" },
  { id:54, grupo:"I", local:"Senegal",      visitante:"Fifa Play-Off 2",fecha:"Vie 26 Jun", hora:"13:00", estado:"pendiente" },

  // GRUPO J
  { id:55, grupo:"J", local:"Argentina",    visitante:"Argelia",       fecha:"Mar 16 Jun", hora:"19:00", estado:"pendiente" },
  { id:56, grupo:"J", local:"Austria",      visitante:"Jordania",      fecha:"Mar 16 Jun", hora:"22:00", estado:"pendiente" },
  { id:57, grupo:"J", local:"Argentina",    visitante:"Austria",       fecha:"Lun 22 Jun", hora:"11:00", estado:"pendiente" },
  { id:58, grupo:"J", local:"Jordania",     visitante:"Argelia",       fecha:"Lun 22 Jun", hora:"21:00", estado:"pendiente" },
  { id:59, grupo:"J", local:"Jordania",     visitante:"Argentina",     fecha:"Sáb 27 Jun", hora:"20:00", estado:"pendiente" },
  { id:60, grupo:"J", local:"Argelia",      visitante:"Austria",       fecha:"Sáb 27 Jun", hora:"20:00", estado:"pendiente" },

  // GRUPO K
  { id:61, grupo:"K", local:"Portugal",     visitante:"Fifa Play-Off 1",fecha:"Mié 17 Jun", hora:"11:00", estado:"pendiente" },
  { id:62, grupo:"K", local:"Uzbekistán",   visitante:"Colombia",      fecha:"Mié 17 Jun", hora:"20:00", estado:"pendiente" },
  { id:63, grupo:"K", local:"Portugal",     visitante:"Uzbekistán",    fecha:"Mar 23 Jun", hora:"11:00", estado:"pendiente" },
  { id:64, grupo:"K", local:"Colombia",     visitante:"Fifa Play-Off 1",fecha:"Mar 23 Jun", hora:"20:00", estado:"pendiente" },
  { id:65, grupo:"K", local:"Fifa Play-Off 1",visitante:"Uzbekistán",  fecha:"Sáb 27 Jun", hora:"17:30", estado:"pendiente" },
  { id:66, grupo:"K", local:"Colombia",     visitante:"Portugal",      fecha:"Sáb 27 Jun", hora:"17:30", estado:"pendiente" },

  // GRUPO L
  { id:67, grupo:"L", local:"Inglaterra",   visitante:"Croacia",       fecha:"Mié 17 Jun", hora:"14:00", estado:"pendiente" },
  { id:68, grupo:"L", local:"Ghana",        visitante:"Panamá",        fecha:"Mié 17 Jun", hora:"17:00", estado:"pendiente" },
  { id:69, grupo:"L", local:"Inglaterra",   visitante:"Ghana",         fecha:"Mar 23 Jun", hora:"14:00", estado:"pendiente" },
  { id:70, grupo:"L", local:"Panamá",       visitante:"Croacia",       fecha:"Mar 23 Jun", hora:"17:00", estado:"pendiente" },
  { id:71, grupo:"L", local:"Panamá",       visitante:"Inglaterra",    fecha:"Sáb 27 Jun", hora:"15:00", estado:"pendiente" },
  { id:72, grupo:"L", local:"Croacia",      visitante:"Ghana",         fecha:"Sáb 27 Jun", hora:"15:00", estado:"pendiente" },

  // FASE ELIMINATORIA (sin equipos definidos aún)
  { id:73,  grupo:"Ronda 32", local:"1A",  visitante:"3C/3E/3F/3H/3I", fase:"Ronda de 32",    fecha:"Dom 28 Jun", hora:"13:00", estado:"pendiente" },
  { id:74,  grupo:"Ronda 32", local:"2A",  visitante:"2B",             fase:"Ronda de 32",    fecha:"Dom 28 Jun", hora:"13:00", estado:"pendiente" },
  { id:75,  grupo:"Ronda 32", local:"1C",  visitante:"2F",             fase:"Ronda de 32",    fecha:"Lun 29 Jun", hora:"11:00", estado:"pendiente" },
  { id:76,  grupo:"Ronda 32", local:"1E",  visitante:"3A/B/C/D/F",    fase:"Ronda de 32",    fecha:"Lun 29 Jun", hora:"14:30", estado:"pendiente" },
  { id:77,  grupo:"Ronda 32", local:"1F",  visitante:"2C",             fase:"Ronda de 32",    fecha:"Lun 29 Jun", hora:"19:00", estado:"pendiente" },
  { id:78,  grupo:"Ronda 32", local:"2E",  visitante:"2I",             fase:"Ronda de 32",    fecha:"Mar 30 Jun", hora:"11:00", estado:"pendiente" },
  { id:79,  grupo:"Ronda 32", local:"1I",  visitante:"3C/D/F/G/H",    fase:"Ronda de 32",    fecha:"Mar 30 Jun", hora:"15:00", estado:"pendiente" },
  { id:80,  grupo:"Ronda 32", local:"1L",  visitante:"3E/H/I/J/K",    fase:"Ronda de 32",    fecha:"Mié 1 Jul",  hora:"10:00", estado:"pendiente" },
  { id:81,  grupo:"Ronda 32", local:"1G",  visitante:"3A/E/H/I/J",    fase:"Ronda de 32",    fecha:"Mié 1 Jul",  hora:"14:00", estado:"pendiente" },
  { id:82,  grupo:"Ronda 32", local:"1D",  visitante:"3B/E/F/I/J",    fase:"Ronda de 32",    fecha:"Mié 1 Jul",  hora:"18:00", estado:"pendiente" },
  { id:83,  grupo:"Ronda 32", local:"1H",  visitante:"2J",             fase:"Ronda de 32",    fecha:"Jue 2 Jul",  hora:"13:00", estado:"pendiente" },
  { id:84,  grupo:"Ronda 32", local:"2K",  visitante:"2L",             fase:"Ronda de 32",    fecha:"Jue 2 Jul",  hora:"17:00", estado:"pendiente" },
  { id:85,  grupo:"Ronda 32", local:"1B",  visitante:"3E/F/G/I/J",    fase:"Ronda de 32",    fecha:"Jue 2 Jul",  hora:"21:00", estado:"pendiente" },
  { id:86,  grupo:"Ronda 32", local:"2D",  visitante:"2G",             fase:"Ronda de 32",    fecha:"Vie 3 Jul",  hora:"12:00", estado:"pendiente" },
  { id:87,  grupo:"Ronda 32", local:"1J",  visitante:"2H",             fase:"Ronda de 32",    fecha:"Vie 3 Jul",  hora:"16:00", estado:"pendiente" },
  { id:88,  grupo:"Ronda 32", local:"1K",  visitante:"3D/E/I/J/L",    fase:"Ronda de 32",    fecha:"Vie 3 Jul",  hora:"19:30", estado:"pendiente" },
  // OCTAVOS
  { id:89,  fase:"Octavos", local:"W73", visitante:"W75", fecha:"Sáb 4 Jul",  hora:"11:00", estado:"pendiente" },
  { id:90,  fase:"Octavos", local:"W74", visitante:"W77", fecha:"Sáb 4 Jul",  hora:"15:00", estado:"pendiente" },
  { id:91,  fase:"Octavos", local:"W76", visitante:"W78", fecha:"Dom 5 Jul",  hora:"14:00", estado:"pendiente" },
  { id:92,  fase:"Octavos", local:"W79", visitante:"W80", fecha:"Dom 5 Jul",  hora:"18:00", estado:"pendiente" },
  { id:93,  fase:"Octavos", local:"W83", visitante:"W84", fecha:"Lun 6 Jul",  hora:"13:00", estado:"pendiente" },
  { id:94,  fase:"Octavos", local:"W81", visitante:"W82", fecha:"Lun 6 Jul",  hora:"18:00", estado:"pendiente" },
  { id:95,  fase:"Octavos", local:"W86", visitante:"W88", fecha:"Mar 7 Jul",  hora:"10:00", estado:"pendiente" },
  { id:96,  fase:"Octavos", local:"W85", visitante:"W87", fecha:"Mar 7 Jul",  hora:"14:00", estado:"pendiente" },
  // CUARTOS
  { id:97,  fase:"Cuartos", local:"W89", visitante:"W90", fecha:"Jue 9 Jul",  hora:"14:00", estado:"pendiente" },
  { id:98,  fase:"Cuartos", local:"W93", visitante:"W94", fecha:"Vie 10 Jul", hora:"13:00", estado:"pendiente" },
  { id:99,  fase:"Cuartos", local:"W91", visitante:"W92", fecha:"Sáb 11 Jul", hora:"15:00", estado:"pendiente" },
  { id:100, fase:"Cuartos", local:"W95", visitante:"W96", fecha:"Sáb 11 Jul", hora:"19:00", estado:"pendiente" },
  // SEMIS
  { id:101, fase:"Semifinales", local:"W97", visitante:"W98", fecha:"Mar 14 Jul", hora:"13:00", estado:"pendiente" },
  { id:102, fase:"Semifinales", local:"W99", visitante:"W100",fecha:"Mié 15 Jul", hora:"13:00", estado:"pendiente" },
  // 3ER LUGAR Y FINAL
  { id:103, fase:"3er Lugar", local:"L101",visitante:"L102",fecha:"Sáb 18 Jul", hora:"15:00", estado:"pendiente" },
  { id:104, fase:"Final",      local:"W101",visitante:"W102",fecha:"Dom 19 Jul", hora:"13:00", estado:"pendiente" },
];

// ── GRUPOS ────────────────────────────────────────────────
const GRUPOS = {
  A: ["México", "Sudáfrica", "Corea del Sur", "UEFA Play-Off D"],
  B: ["Canadá", "Catar", "Suiza", "UEFA Play-Off A"],
  C: ["Brasil", "Marruecos", "Haití", "Escocia"],
  D: ["EEUU", "Paraguay", "Australia", "UEFA Play-Off C"],
  E: ["Alemania", "Curasao", "Costa de Marfil", "Ecuador"],
  F: ["Holanda", "Japón", "UEFA Play-Off B", "Túnez"],
  G: ["Bélgica", "Egipto", "Irán", "Nueva Zelanda"],
  H: ["España", "Cabo Verde", "Arabia Saudí", "Uruguay"],
  I: ["Francia", "Senegal", "Fifa Play-Off 2", "Noruega"],
  J: ["Argentina", "Argelia", "Austria", "Jordania"],
  K: ["Portugal", "Uzbekistán", "Colombia", "Fifa Play-Off 1"],
  L: ["Inglaterra", "Croacia", "Ghana", "Panamá"],
};

// ── FUNCIONES GLOBALES ────────────────────────────────────

function obtenerPartidos() {
  const guardados = localStorage.getItem('partidos_mundial');
  if (guardados) return JSON.parse(guardados);
  return PARTIDOS;
}

function guardarPartidos(partidos) {
  localStorage.setItem('partidos_mundial', JSON.stringify(partidos));
}

function obtenerStats() {
  const guardadas = localStorage.getItem('stats_equipos');
  if (guardadas) return JSON.parse(guardadas);
  return EQUIPOS_STATS;
}

function guardarStats(stats) {
  localStorage.setItem('stats_equipos', JSON.stringify(stats));
}

// ── MOTOR DE PREDICCIÓN ESTADÍSTICA ──────────────────────

function predecirPartido(equipoA, equipoB) {
  const stats = obtenerStats();
  const A = stats[equipoA] || { goles:1.2, tarjetas:1.5, offsides:1.4, ranking:50 };
  const B = stats[equipoB] || { goles:1.2, tarjetas:1.5, offsides:1.4, ranking:50 };

  // Factor de fuerza por ranking FIFA
  const rankFactor = (equipo) => {
    const r = equipo.ranking;
    if (r <= 5)  return 1.20;
    if (r <= 15) return 1.10;
    if (r <= 30) return 1.00;
    if (r <= 50) return 0.90;
    return 0.80;
  };

  const golesA = +(A.goles * rankFactor(A) * 0.9).toFixed(1);
  const golesB = +(B.goles * rankFactor(B) * 0.9).toFixed(1);

  // Redondear a enteros para marcador
  const marcA = Math.round(golesA);
  const marcB = Math.round(golesB);

  // Probabilidades
  const total = A.goles + B.goles;
  const probA = total > 0 ? Math.round((A.goles / total) * 100 * rankFactor(A) / rankFactor(B)) : 50;
  const probEmpate = Math.max(0, 100 - probA - Math.max(0, 100 - probA - 20));
  const probB = 100 - probA - 10;

  // Tarjetas y offsides
  const tarjAm = +((A.tarjetas + B.tarjetas) / 2).toFixed(1);
  const tarjRj = +(tarjAm * 0.15).toFixed(1);
  const offs   = +((A.offsides + B.offsides) / 2).toFixed(1);

  // Explicación
  let explicacion = '';
  if (A.goles > B.goles) {
    explicacion = `${equipoA} tiene mayor promedio de goles (${A.goles} vs ${B.goles}) lo que favorece su ataque.`;
  } else if (B.goles > A.goles) {
    explicacion = `${equipoB} tiene mayor promedio de goles (${B.goles} vs ${A.goles}) lo que favorece su ataque.`;
  } else {
    explicacion = `Ambos equipos tienen estadísticas de goles similares, lo que pronostica un partido equilibrado.`;
  }

  if (A.ranking < B.ranking) {
    explicacion += ` Además, ${equipoA} tiene mejor posición FIFA (#${A.ranking} vs #${B.ranking}).`;
  } else if (B.ranking < A.ranking) {
    explicacion += ` Además, ${equipoB} tiene mejor posición FIFA (#${B.ranking} vs #${A.ranking}).`;
  }

  return {
    marcA, marcB,
    probA: Math.min(70, Math.max(20, probA)),
    probEmpate: 15,
    probB: Math.min(70, Math.max(15, 100 - Math.min(70,probA) - 15)),
    tarjAm, tarjRj, offs,
    explicacion,
    golesA, golesB,
    rankA: A.ranking,
    rankB: B.ranking
  };
}

// ── CLASIFICACIÓN DE GRUPOS ───────────────────────────────

function calcularClasificacion(grupo) {
  const partidos = obtenerPartidos();
  const equipos = GRUPOS[grupo];
  if (!equipos) return [];

  const tabla = {};
  equipos.forEach(eq => {
    tabla[eq] = { equipo: eq, pj:0, pg:0, pe:0, pp:0, gf:0, gc:0, dg:0, pts:0 };
  });

  partidos
    .filter(p => p.grupo === grupo && p.estado === 'finalizado')
    .forEach(p => {
      const local = tabla[p.local];
      const visit = tabla[p.visitante];
      if (!local || !visit) return;

      local.pj++; visit.pj++;
      local.gf += p.golesLocal || 0; local.gc += p.golesVisitante || 0;
      visit.gf += p.golesVisitante || 0; visit.gc += p.golesLocal || 0;

      if (p.golesLocal > p.golesVisitante) {
        local.pg++; local.pts += 3; visit.pp++;
      } else if (p.golesLocal < p.golesVisitante) {
        visit.pg++; visit.pts += 3; local.pp++;
      } else {
        local.pe++; visit.pe++; local.pts++; visit.pts++;
      }
    });

  return Object.values(tabla)
    .map(e => ({ ...e, dg: e.gf - e.gc }))
    .sort((a,b) => b.pts - a.pts || b.dg - a.dg || b.gf - a.gf);
}

// ── SISTEMA DE QUINIELA ───────────────────────────────────

function calcularPuntos(prediccion, resultado) {
  if (!resultado || resultado.estado !== 'finalizado') return 0;
  const ra = resultado.golesLocal, rb = resultado.golesVisitante;
  const pa = prediccion.golesLocal, pb = prediccion.golesVisitante;

  if (pa === ra && pb === rb) return 5; // Resultado exacto
  
  const ganadorReal = ra > rb ? 'L' : rb > ra ? 'V' : 'E';
  const ganadorPred = pa > pb ? 'L' : pb > pa ? 'V' : 'E';
  
  if (ganadorReal === ganadorPred && (ra - rb) === (pa - pb)) return 3; // Diferencia exacta
  if (ganadorReal === ganadorPred) return 2; // Ganador correcto
  if ((ra + rb) === (pa + pb)) return 1; // Goles totales correctos
  return 0;
}

function obtenerUsuarios() {
  return JSON.parse(localStorage.getItem('usuarios_mundial') || '[]');
}

function guardarUsuarios(usuarios) {
  localStorage.setItem('usuarios_mundial', JSON.stringify(usuarios));
}

function obtenerPredicciones(usuario) {
  return JSON.parse(localStorage.getItem(`preds_${usuario}`) || '{}');
}

function guardarPredicciones(usuario, preds) {
  localStorage.setItem(`preds_${usuario}`, JSON.stringify(preds));
}

function calcularTablaPuntos() {
  const usuarios = obtenerUsuarios();
  const partidos = obtenerPartidos();
  
  return usuarios
    .filter(u => !u.esAdmin)
    .map(u => {
      const preds = obtenerPredicciones(u.usuario);
      let total = 0;
      partidos.forEach(p => {
        if (preds[p.id]) {
          total += calcularPuntos(preds[p.id], p);
        }
      });
      return { ...u, puntos: total };
    })
    .sort((a, b) => b.puntos - a.puntos);
}

// ── INICIALIZAR ADMIN ─────────────────────────────────────
(function() {
  const usuarios = obtenerUsuarios();
  if (!usuarios.find(u => u.usuario === 'admin')) {
    usuarios.push({
      nombre: 'Administrador',
      usuario: 'admin',
      password: btoa('admin123'),
      esAdmin: true
    });
    guardarUsuarios(usuarios);
  }
})();

// ── DEADLINE: editable hasta las 9:30am hora Guatemala del día del partido ──
function partidoEditable(partido) {
  if (partido.estado === 'finalizado') return false;
  
  // Mapeo de fechas de partidos a fechas reales
  const fechaMap = {
    "Jue 11 Jun": "2026-06-11", "Vie 12 Jun": "2026-06-12",
    "Sáb 13 Jun": "2026-06-13", "Dom 14 Jun": "2026-06-14",
    "Lun 15 Jun": "2026-06-15", "Mar 16 Jun": "2026-06-16",
    "Mié 17 Jun": "2026-06-17", "Jue 18 Jun": "2026-06-18",
    "Vie 19 Jun": "2026-06-19", "Sáb 20 Jun": "2026-06-20",
    "Dom 21 Jun": "2026-06-21", "Lun 22 Jun": "2026-06-22",
    "Mar 23 Jun": "2026-06-23", "Mié 24 Jun": "2026-06-24",
    "Jue 25 Jun": "2026-06-25", "Vie 26 Jun": "2026-06-26",
    "Sáb 27 Jun": "2026-06-27", "Dom 28 Jun": "2026-06-28",
    "Lun 29 Jun": "2026-06-29", "Mar 30 Jun": "2026-06-30",
    "Mié 1 Jul":  "2026-07-01", "Jue 2 Jul":  "2026-07-02",
    "Vie 3 Jul":  "2026-07-03", "Sáb 4 Jul":  "2026-07-04",
    "Dom 5 Jul":  "2026-07-05", "Lun 6 Jul":  "2026-07-06",
    "Mar 7 Jul":  "2026-07-07", "Jue 9 Jul":  "2026-07-09",
    "Vie 10 Jul": "2026-07-10", "Sáb 11 Jul": "2026-07-11",
    "Mar 14 Jul": "2026-07-14", "Mié 15 Jul": "2026-07-15",
    "Sáb 18 Jul": "2026-07-18", "Dom 19 Jul": "2026-07-19",
  };
  
  const fechaStr = fechaMap[partido.fecha];
  if (!fechaStr) return true; // Si no encontramos fecha, permitir edición
  
  // Deadline: 9:30 AM hora Guatemala (UTC-6) = 15:30 UTC
  const deadline = new Date(fechaStr + 'T15:30:00Z');
  const ahora = new Date();
  
  return ahora < deadline;
}

// Retorna texto descriptivo del deadline
function textoDeadline(partido) {
  const fechaMap = {
    "Jue 11 Jun": "2026-06-11", "Vie 12 Jun": "2026-06-12",
    "Sáb 13 Jun": "2026-06-13", "Dom 14 Jun": "2026-06-14",
    "Lun 15 Jun": "2026-06-15", "Mar 16 Jun": "2026-06-16",
    "Mié 17 Jun": "2026-06-17", "Jue 18 Jun": "2026-06-18",
    "Vie 19 Jun": "2026-06-19", "Sáb 20 Jun": "2026-06-20",
    "Dom 21 Jun": "2026-06-21", "Lun 22 Jun": "2026-06-22",
    "Mar 23 Jun": "2026-06-23", "Mié 24 Jun": "2026-06-24",
    "Jue 25 Jun": "2026-06-25", "Vie 26 Jun": "2026-06-26",
    "Sáb 27 Jun": "2026-06-27",
  };
  const fechaStr = fechaMap[partido.fecha];
  if (!fechaStr) return '';
  return `Cierra: ${partido.fecha} 9:30am`;
}

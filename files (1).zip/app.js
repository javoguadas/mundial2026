// ============================================================
//  MUNDIAL 2026 — app.js  (versión completa)
// ============================================================

// ── RANKING FIFA OFICIAL ─────────────────────────────────
const EQUIPOS_STATS = {
  "España":           { goles:2.3, tarjetas:1.2, offsides:1.7, ranking:1  },
  "Argentina":        { goles:2.2, tarjetas:1.5, offsides:1.6, ranking:2  },
  "Francia":          { goles:2.0, tarjetas:1.4, offsides:1.5, ranking:3  },
  "Inglaterra":       { goles:1.9, tarjetas:1.4, offsides:1.7, ranking:4  },
  "Brasil":           { goles:2.1, tarjetas:1.3, offsides:1.2, ranking:5  },
  "Portugal":         { goles:2.2, tarjetas:1.5, offsides:1.7, ranking:6  },
  "Holanda":          { goles:1.9, tarjetas:1.4, offsides:1.7, ranking:7  },
  "Marruecos":        { goles:1.5, tarjetas:1.7, offsides:1.3, ranking:8  },
  "Bélgica":          { goles:1.8, tarjetas:1.4, offsides:1.5, ranking:9  },
  "Alemania":         { goles:2.0, tarjetas:1.4, offsides:1.8, ranking:10 },
  "Croacia":          { goles:1.6, tarjetas:1.4, offsides:1.5, ranking:11 },
  "Senegal":          { goles:1.8, tarjetas:1.5, offsides:1.4, ranking:12 },
  "Colombia":         { goles:1.7, tarjetas:1.6, offsides:1.5, ranking:14 },
  "EEUU":             { goles:1.8, tarjetas:1.5, offsides:1.6, ranking:15 },
  "México":           { goles:1.8, tarjetas:1.8, offsides:2.1, ranking:16 },
  "Uruguay":          { goles:1.7, tarjetas:1.5, offsides:1.3, ranking:17 },
  "Suiza":            { goles:1.7, tarjetas:1.3, offsides:1.4, ranking:18 },
  "Japón":            { goles:1.6, tarjetas:1.2, offsides:1.5, ranking:19 },
  "Irán":             { goles:1.3, tarjetas:1.9, offsides:1.3, ranking:20 },
  "Corea del Sur":    { goles:1.6, tarjetas:1.5, offsides:1.8, ranking:22 },
  "Ecuador":          { goles:1.4, tarjetas:1.6, offsides:1.5, ranking:23 },
  "Austria":          { goles:1.7, tarjetas:1.5, offsides:1.6, ranking:24 },
  "Australia":        { goles:1.3, tarjetas:1.5, offsides:1.4, ranking:27 },
  "Argelia":          { goles:1.4, tarjetas:1.8, offsides:1.4, ranking:28 },
  "Canadá":           { goles:1.5, tarjetas:1.4, offsides:1.6, ranking:29 },
  "Egipto":           { goles:1.4, tarjetas:1.7, offsides:1.4, ranking:31 },
  "Noruega":          { goles:1.8, tarjetas:1.3, offsides:1.9, ranking:32 },
  "Panamá":           { goles:1.2, tarjetas:1.9, offsides:1.2, ranking:33 },
  "Costa de Marfil":  { goles:1.5, tarjetas:1.7, offsides:1.4, ranking:37 },
  "Escocia":          { goles:1.4, tarjetas:1.6, offsides:1.7, ranking:38 },
  "Paraguay":         { goles:1.2, tarjetas:1.9, offsides:1.3, ranking:40 },
  "Túnez":            { goles:1.2, tarjetas:1.8, offsides:1.3, ranking:47 },
  "Uzbekistán":       { goles:1.1, tarjetas:1.7, offsides:1.3, ranking:52 },
  "Catar":            { goles:1.1, tarjetas:1.8, offsides:1.2, ranking:56 },
  "Sudáfrica":        { goles:1.2, tarjetas:1.9, offsides:1.5, ranking:60 },
  "Arabia Saudí":     { goles:1.3, tarjetas:1.8, offsides:1.4, ranking:61 },
  "Jordania":         { goles:1.0, tarjetas:1.8, offsides:1.1, ranking:64 },
  "Cabo Verde":       { goles:1.1, tarjetas:1.9, offsides:1.2, ranking:67 },
  "Ghana":            { goles:1.2, tarjetas:1.8, offsides:1.3, ranking:72 },
  "Curasao":          { goles:0.9, tarjetas:2.0, offsides:1.0, ranking:81 },
  "Haití":            { goles:0.8, tarjetas:2.1, offsides:1.1, ranking:83 },
  "Nueva Zelanda":    { goles:1.1, tarjetas:1.5, offsides:1.2, ranking:85 },
  "UEFA Play-Off A":  { goles:1.5, tarjetas:1.5, offsides:1.5, ranking:35 },
  "UEFA Play-Off B":  { goles:1.4, tarjetas:1.6, offsides:1.4, ranking:43 },
  "UEFA Play-Off C":  { goles:1.4, tarjetas:1.6, offsides:1.4, ranking:46 },
  "UEFA Play-Off D":  { goles:1.3, tarjetas:1.6, offsides:1.3, ranking:50 },
  "Fifa Play-Off 1":  { goles:1.3, tarjetas:1.7, offsides:1.3, ranking:55 },
  "Fifa Play-Off 2":  { goles:1.2, tarjetas:1.7, offsides:1.2, ranking:58 },
};

// ── MAPA FECHA → ISO (para deadline) ─────────────────────
const FECHA_ISO = {
  "Jue 11 Jun":"2026-06-11","Vie 12 Jun":"2026-06-12",
  "Sáb 13 Jun":"2026-06-13","Dom 14 Jun":"2026-06-14",
  "Lun 15 Jun":"2026-06-15","Mar 16 Jun":"2026-06-16",
  "Mié 17 Jun":"2026-06-17","Jue 18 Jun":"2026-06-18",
  "Vie 19 Jun":"2026-06-19","Sáb 20 Jun":"2026-06-20",
  "Dom 21 Jun":"2026-06-21","Lun 22 Jun":"2026-06-22",
  "Mar 23 Jun":"2026-06-23","Mié 24 Jun":"2026-06-24",
  "Jue 25 Jun":"2026-06-25","Vie 26 Jun":"2026-06-26",
  "Sáb 27 Jun":"2026-06-27","Dom 28 Jun":"2026-06-28",
  "Lun 29 Jun":"2026-06-29","Mar 30 Jun":"2026-06-30",
  "Mié 1 Jul" :"2026-07-01","Jue 2 Jul" :"2026-07-02",
  "Vie 3 Jul" :"2026-07-03","Sáb 4 Jul" :"2026-07-04",
  "Dom 5 Jul" :"2026-07-05","Lun 6 Jul" :"2026-07-06",
  "Mar 7 Jul" :"2026-07-07","Jue 9 Jul" :"2026-07-09",
  "Vie 10 Jul":"2026-07-10","Sáb 11 Jul":"2026-07-11",
  "Mar 14 Jul":"2026-07-14","Mié 15 Jul":"2026-07-15",
  "Sáb 18 Jul":"2026-07-18","Dom 19 Jul":"2026-07-19",
};

// ── CALENDARIO COMPLETO (ordenado por fecha/hora) ─────────
// NOTA: Los partidos de fase de grupos tienen campo "grupo" (una letra A-L)
// Los partidos eliminatorios tienen campo "fase" y NO "grupo"
// Penales: partido puede tener penalesLocal / penalesVisitante + tienePenales:true
const PARTIDOS = [
  // ─── 11 JUNIO ───
  { id:1,  num:1,  grupo:"A", local:"México",          visitante:"Sudáfrica",       fecha:"Jue 11 Jun", hora:"13:00", estado:"pendiente" },
  { id:2,  num:2,  grupo:"A", local:"Corea del Sur",   visitante:"UEFA Play-Off D", fecha:"Jue 11 Jun", hora:"20:00", estado:"pendiente" },
  // ─── 12 JUNIO ───
  { id:7,  num:7,  grupo:"B", local:"Canadá",          visitante:"UEFA Play-Off A", fecha:"Vie 12 Jun", hora:"13:00", estado:"pendiente" },
  { id:19, num:19, grupo:"D", local:"EEUU",             visitante:"Paraguay",        fecha:"Vie 12 Jun", hora:"19:00", estado:"pendiente" },
  // ─── 13 JUNIO ───
  { id:8,  num:8,  grupo:"B", local:"Catar",            visitante:"Suiza",           fecha:"Sáb 13 Jun", hora:"13:00", estado:"pendiente" },
  { id:13, num:13, grupo:"C", local:"Brasil",           visitante:"Marruecos",       fecha:"Sáb 13 Jun", hora:"16:00", estado:"pendiente" },
  { id:14, num:14, grupo:"C", local:"Haití",            visitante:"Escocia",         fecha:"Sáb 13 Jun", hora:"19:00", estado:"pendiente" },
  { id:20, num:20, grupo:"D", local:"Australia",        visitante:"UEFA Play-Off C", fecha:"Sáb 13 Jun", hora:"22:00", estado:"pendiente" },
  // ─── 14 JUNIO ───
  { id:25, num:25, grupo:"E", local:"Alemania",         visitante:"Curasao",         fecha:"Dom 14 Jun", hora:"11:00", estado:"pendiente" },
  { id:31, num:31, grupo:"F", local:"Holanda",          visitante:"Japón",           fecha:"Dom 14 Jun", hora:"14:00", estado:"pendiente" },
  { id:26, num:26, grupo:"E", local:"Costa de Marfil",  visitante:"Ecuador",         fecha:"Dom 14 Jun", hora:"17:00", estado:"pendiente" },
  { id:32, num:32, grupo:"F", local:"UEFA Play-Off B",  visitante:"Túnez",           fecha:"Dom 14 Jun", hora:"20:00", estado:"pendiente" },
  // ─── 15 JUNIO ───
  { id:43, num:43, grupo:"H", local:"España",           visitante:"Cabo Verde",      fecha:"Lun 15 Jun", hora:"10:00", estado:"pendiente" },
  { id:37, num:37, grupo:"G", local:"Bélgica",          visitante:"Egipto",          fecha:"Lun 15 Jun", hora:"13:00", estado:"pendiente" },
  { id:44, num:44, grupo:"H", local:"Arabia Saudí",     visitante:"Uruguay",         fecha:"Lun 15 Jun", hora:"16:00", estado:"pendiente" },
  { id:38, num:38, grupo:"G", local:"Irán",             visitante:"Nueva Zelanda",   fecha:"Lun 15 Jun", hora:"19:00", estado:"pendiente" },
  // ─── 16 JUNIO ───
  { id:49, num:49, grupo:"I", local:"Francia",          visitante:"Senegal",         fecha:"Mar 16 Jun", hora:"13:00", estado:"pendiente" },
  { id:50, num:50, grupo:"I", local:"Fifa Play-Off 2",  visitante:"Noruega",         fecha:"Mar 16 Jun", hora:"16:00", estado:"pendiente" },
  { id:55, num:55, grupo:"J", local:"Argentina",        visitante:"Argelia",         fecha:"Mar 16 Jun", hora:"19:00", estado:"pendiente" },
  { id:56, num:56, grupo:"J", local:"Austria",          visitante:"Jordania",        fecha:"Mar 16 Jun", hora:"22:00", estado:"pendiente" },
  // ─── 17 JUNIO ───
  { id:61, num:61, grupo:"K", local:"Portugal",         visitante:"Fifa Play-Off 1", fecha:"Mié 17 Jun", hora:"11:00", estado:"pendiente" },
  { id:67, num:67, grupo:"L", local:"Inglaterra",       visitante:"Croacia",         fecha:"Mié 17 Jun", hora:"14:00", estado:"pendiente" },
  { id:68, num:68, grupo:"L", local:"Ghana",            visitante:"Panamá",          fecha:"Mié 17 Jun", hora:"17:00", estado:"pendiente" },
  { id:62, num:62, grupo:"K", local:"Uzbekistán",       visitante:"Colombia",        fecha:"Mié 17 Jun", hora:"20:00", estado:"pendiente" },
  // ─── 18 JUNIO ───
  { id:3,  num:3,  grupo:"A", local:"UEFA Play-Off D",  visitante:"Sudáfrica",       fecha:"Jue 18 Jun", hora:"10:00", estado:"pendiente" },
  { id:9,  num:9,  grupo:"B", local:"Suiza",            visitante:"UEFA Play-Off A", fecha:"Jue 18 Jun", hora:"13:00", estado:"pendiente" },
  { id:10, num:10, grupo:"B", local:"Canadá",           visitante:"Catar",           fecha:"Jue 18 Jun", hora:"16:00", estado:"pendiente" },
  { id:4,  num:4,  grupo:"A", local:"México",           visitante:"Corea del Sur",   fecha:"Jue 18 Jun", hora:"19:00", estado:"pendiente" },
  // ─── 19 JUNIO ───
  { id:21, num:21, grupo:"D", local:"EEUU",             visitante:"Australia",       fecha:"Vie 19 Jun", hora:"13:00", estado:"pendiente" },
  { id:15, num:15, grupo:"C", local:"Escocia",          visitante:"Marruecos",       fecha:"Vie 19 Jun", hora:"16:00", estado:"pendiente" },
  { id:16, num:16, grupo:"C", local:"Brasil",           visitante:"Haití",           fecha:"Vie 19 Jun", hora:"19:00", estado:"pendiente" },
  { id:22, num:22, grupo:"D", local:"UEFA Play-Off C",  visitante:"Paraguay",        fecha:"Vie 19 Jun", hora:"22:00", estado:"pendiente" },
  // ─── 20 JUNIO ───
  { id:33, num:33, grupo:"F", local:"Holanda",          visitante:"UEFA Play-Off B", fecha:"Sáb 20 Jun", hora:"11:00", estado:"pendiente" },
  { id:27, num:27, grupo:"E", local:"Alemania",         visitante:"Costa de Marfil", fecha:"Sáb 20 Jun", hora:"14:00", estado:"pendiente" },
  { id:28, num:28, grupo:"E", local:"Ecuador",          visitante:"Curasao",         fecha:"Sáb 20 Jun", hora:"18:00", estado:"pendiente" },
  { id:34, num:34, grupo:"F", local:"Túnez",            visitante:"Japón",           fecha:"Sáb 20 Jun", hora:"22:00", estado:"pendiente" },
  // ─── 21 JUNIO ───
  { id:45, num:45, grupo:"H", local:"España",           visitante:"Arabia Saudí",    fecha:"Dom 21 Jun", hora:"10:00", estado:"pendiente" },
  { id:39, num:39, grupo:"G", local:"Bélgica",          visitante:"Irán",            fecha:"Dom 21 Jun", hora:"13:00", estado:"pendiente" },
  { id:46, num:46, grupo:"H", local:"Uruguay",          visitante:"Cabo Verde",      fecha:"Dom 21 Jun", hora:"16:00", estado:"pendiente" },
  { id:40, num:40, grupo:"G", local:"Nueva Zelanda",    visitante:"Egipto",          fecha:"Dom 21 Jun", hora:"19:00", estado:"pendiente" },
  // ─── 22 JUNIO ───
  { id:57, num:57, grupo:"J", local:"Argentina",        visitante:"Austria",         fecha:"Lun 22 Jun", hora:"11:00", estado:"pendiente" },
  { id:51, num:51, grupo:"I", local:"Francia",          visitante:"Fifa Play-Off 2", fecha:"Lun 22 Jun", hora:"15:00", estado:"pendiente" },
  { id:52, num:52, grupo:"I", local:"Noruega",          visitante:"Senegal",         fecha:"Lun 22 Jun", hora:"18:00", estado:"pendiente" },
  { id:58, num:58, grupo:"J", local:"Jordania",         visitante:"Argelia",         fecha:"Lun 22 Jun", hora:"21:00", estado:"pendiente" },
  // ─── 23 JUNIO ───
  { id:63, num:63, grupo:"K", local:"Portugal",         visitante:"Uzbekistán",      fecha:"Mar 23 Jun", hora:"11:00", estado:"pendiente" },
  { id:69, num:69, grupo:"L", local:"Inglaterra",       visitante:"Ghana",           fecha:"Mar 23 Jun", hora:"14:00", estado:"pendiente" },
  { id:70, num:70, grupo:"L", local:"Panamá",           visitante:"Croacia",         fecha:"Mar 23 Jun", hora:"17:00", estado:"pendiente" },
  { id:64, num:64, grupo:"K", local:"Colombia",         visitante:"Fifa Play-Off 1", fecha:"Mar 23 Jun", hora:"20:00", estado:"pendiente" },
  // ─── 24 JUNIO ───
  { id:11, num:11, grupo:"B", local:"Suiza",            visitante:"Canadá",          fecha:"Mié 24 Jun", hora:"13:00", estado:"pendiente" },
  { id:12, num:12, grupo:"B", local:"UEFA Play-Off A",  visitante:"Catar",           fecha:"Mié 24 Jun", hora:"13:00", estado:"pendiente" },
  { id:17, num:17, grupo:"C", local:"Escocia",          visitante:"Brasil",          fecha:"Mié 24 Jun", hora:"16:00", estado:"pendiente" },
  { id:18, num:18, grupo:"C", local:"Marruecos",        visitante:"Haití",           fecha:"Mié 24 Jun", hora:"16:00", estado:"pendiente" },
  { id:5,  num:5,  grupo:"A", local:"UEFA Play-Off D",  visitante:"México",          fecha:"Mié 24 Jun", hora:"19:00", estado:"pendiente" },
  { id:6,  num:6,  grupo:"A", local:"Sudáfrica",        visitante:"Corea del Sur",   fecha:"Mié 24 Jun", hora:"19:00", estado:"pendiente" },
  // ─── 25 JUNIO ───
  { id:29, num:29, grupo:"E", local:"Curasao",          visitante:"Costa de Marfil", fecha:"Jue 25 Jun", hora:"14:00", estado:"pendiente" },
  { id:30, num:30, grupo:"E", local:"Ecuador",          visitante:"Alemania",        fecha:"Jue 25 Jun", hora:"14:00", estado:"pendiente" },
  { id:35, num:35, grupo:"F", local:"Japón",            visitante:"UEFA Play-Off B", fecha:"Jue 25 Jun", hora:"17:00", estado:"pendiente" },
  { id:36, num:36, grupo:"F", local:"Túnez",            visitante:"Holanda",         fecha:"Jue 25 Jun", hora:"17:00", estado:"pendiente" },
  { id:23, num:23, grupo:"D", local:"UEFA Play-Off C",  visitante:"EEUU",            fecha:"Jue 25 Jun", hora:"20:00", estado:"pendiente" },
  { id:24, num:24, grupo:"D", local:"Paraguay",         visitante:"Australia",       fecha:"Jue 25 Jun", hora:"20:00", estado:"pendiente" },
  // ─── 26 JUNIO ───
  { id:53, num:53, grupo:"I", local:"Noruega",          visitante:"Francia",         fecha:"Vie 26 Jun", hora:"13:00", estado:"pendiente" },
  { id:54, num:54, grupo:"I", local:"Senegal",          visitante:"Fifa Play-Off 2", fecha:"Vie 26 Jun", hora:"13:00", estado:"pendiente" },
  { id:47, num:47, grupo:"H", local:"Uruguay",          visitante:"España",          fecha:"Vie 26 Jun", hora:"18:00", estado:"pendiente" },
  { id:48, num:48, grupo:"H", local:"Cabo Verde",       visitante:"Arabia Saudí",    fecha:"Vie 26 Jun", hora:"18:00", estado:"pendiente" },
  { id:41, num:41, grupo:"G", local:"Egipto",           visitante:"Irán",            fecha:"Vie 26 Jun", hora:"21:00", estado:"pendiente" },
  { id:42, num:42, grupo:"G", local:"Nueva Zelanda",    visitante:"Bélgica",         fecha:"Vie 26 Jun", hora:"21:00", estado:"pendiente" },
  // ─── 27 JUNIO ───
  { id:71, num:71, grupo:"L", local:"Panamá",           visitante:"Inglaterra",      fecha:"Sáb 27 Jun", hora:"15:00", estado:"pendiente" },
  { id:72, num:72, grupo:"L", local:"Croacia",          visitante:"Ghana",           fecha:"Sáb 27 Jun", hora:"15:00", estado:"pendiente" },
  { id:65, num:65, grupo:"K", local:"Fifa Play-Off 1",  visitante:"Uzbekistán",      fecha:"Sáb 27 Jun", hora:"17:30", estado:"pendiente" },
  { id:66, num:66, grupo:"K", local:"Colombia",         visitante:"Portugal",        fecha:"Sáb 27 Jun", hora:"17:30", estado:"pendiente" },
  { id:59, num:59, grupo:"J", local:"Jordania",         visitante:"Argentina",       fecha:"Sáb 27 Jun", hora:"20:00", estado:"pendiente" },
  { id:60, num:60, grupo:"J", local:"Argelia",          visitante:"Austria",         fecha:"Sáb 27 Jun", hora:"20:00", estado:"pendiente" },

  // ═══════════════════════════════════════════════════════
  // FASE ELIMINATORIA — DIECISEISAVOS (Partidos 73-88)
  // ═══════════════════════════════════════════════════════
  // Bracket oficial FIFA 2026:
  // P73: 2A vs 2B  |  P74: 1E vs 3ABCDF  |  P75: 1F vs 2C  |  P76: 1C vs 2F
  // P77: 1I vs 3CDFGH | P78: 2E vs 2I   |  P79: 1A vs 3CEFHI | P80: 1L vs 3EHIJK
  // P81: 1D vs 3BEFIJ  | P82: 1G vs 3AEHIJ | P83: 2K vs 2L  | P84: 1H vs 2J
  // P85: 1B vs 3EFGIJ  | P86: 1J vs 2H   |  P87: 1K vs 3DEIJL | P88: 2D vs 2G
  { id:73, num:73, fase:"16avos", local:"2A",  visitante:"2B",           fecha:"Dom 28 Jun", hora:"13:00", estado:"pendiente" },
  { id:74, num:74, fase:"16avos", local:"1E",  visitante:"3A/B/C/D/F",   fecha:"Lun 29 Jun", hora:"14:30", estado:"pendiente" },
  { id:75, num:75, fase:"16avos", local:"1F",  visitante:"2C",           fecha:"Lun 29 Jun", hora:"19:00", estado:"pendiente" },
  { id:76, num:76, fase:"16avos", local:"1C",  visitante:"2F",           fecha:"Lun 29 Jun", hora:"11:00", estado:"pendiente" },
  { id:77, num:77, fase:"16avos", local:"1I",  visitante:"3C/D/F/G/H",   fecha:"Mar 30 Jun", hora:"15:00", estado:"pendiente" },
  { id:78, num:78, fase:"16avos", local:"2E",  visitante:"2I",           fecha:"Mar 30 Jun", hora:"11:00", estado:"pendiente" },
  { id:79, num:79, fase:"16avos", local:"1A",  visitante:"3C/E/F/H/I",   fecha:"Mar 30 Jun", hora:"19:00", estado:"pendiente" },
  { id:80, num:80, fase:"16avos", local:"1L",  visitante:"3E/H/I/J/K",   fecha:"Mié 1 Jul",  hora:"10:00", estado:"pendiente" },
  { id:81, num:81, fase:"16avos", local:"1D",  visitante:"3B/E/F/I/J",   fecha:"Mié 1 Jul",  hora:"18:00", estado:"pendiente" },
  { id:82, num:82, fase:"16avos", local:"1G",  visitante:"3A/E/H/I/J",   fecha:"Mié 1 Jul",  hora:"14:00", estado:"pendiente" },
  { id:83, num:83, fase:"16avos", local:"2K",  visitante:"2L",           fecha:"Jue 2 Jul",  hora:"13:00", estado:"pendiente" },
  { id:84, num:84, fase:"16avos", local:"1H",  visitante:"2J",           fecha:"Jue 2 Jul",  hora:"17:00", estado:"pendiente" },
  { id:85, num:85, fase:"16avos", local:"1B",  visitante:"3E/F/G/I/J",   fecha:"Jue 2 Jul",  hora:"21:00", estado:"pendiente" },
  { id:86, num:86, fase:"16avos", local:"1J",  visitante:"2H",           fecha:"Vie 3 Jul",  hora:"16:00", estado:"pendiente" },
  { id:87, num:87, fase:"16avos", local:"1K",  visitante:"3D/E/I/J/L",   fecha:"Vie 3 Jul",  hora:"19:30", estado:"pendiente" },
  { id:88, num:88, fase:"16avos", local:"2D",  visitante:"2G",           fecha:"Vie 3 Jul",  hora:"12:00", estado:"pendiente" },

  // ═══════════════════════════════════════════════════════
  // OCTAVOS (Partidos 89-96) — Pueden ir a penales
  // P89: W74 vs W77 | P90: W73 vs W75 | P91: W76 vs W78 | P92: W79 vs W80
  // P93: W83 vs W84 | P94: W81 vs W82 | P95: W86 vs W88 | P96: W85 vs W87
  // ═══════════════════════════════════════════════════════
  { id:89, num:89, fase:"Octavos", local:"W74", visitante:"W77", fecha:"Sáb 4 Jul",  hora:"11:00", estado:"pendiente", puedeIrAPenales:true },
  { id:90, num:90, fase:"Octavos", local:"W73", visitante:"W75", fecha:"Sáb 4 Jul",  hora:"15:00", estado:"pendiente", puedeIrAPenales:true },
  { id:91, num:91, fase:"Octavos", local:"W76", visitante:"W78", fecha:"Dom 5 Jul",  hora:"14:00", estado:"pendiente", puedeIrAPenales:true },
  { id:92, num:92, fase:"Octavos", local:"W79", visitante:"W80", fecha:"Dom 5 Jul",  hora:"18:00", estado:"pendiente", puedeIrAPenales:true },
  { id:93, num:93, fase:"Octavos", local:"W83", visitante:"W84", fecha:"Lun 6 Jul",  hora:"13:00", estado:"pendiente", puedeIrAPenales:true },
  { id:94, num:94, fase:"Octavos", local:"W81", visitante:"W82", fecha:"Lun 6 Jul",  hora:"18:00", estado:"pendiente", puedeIrAPenales:true },
  { id:95, num:95, fase:"Octavos", local:"W86", visitante:"W88", fecha:"Mar 7 Jul",  hora:"10:00", estado:"pendiente", puedeIrAPenales:true },
  { id:96, num:96, fase:"Octavos", local:"W85", visitante:"W87", fecha:"Mar 7 Jul",  hora:"14:00", estado:"pendiente", puedeIrAPenales:true },

  // ═══════════════════════════════════════════════════════
  // CUARTOS (Partidos 97-100)
  // P97: W89 vs W90 | P98: W93 vs W94 | P99: W91 vs W92 | P100: W95 vs W96
  // ═══════════════════════════════════════════════════════
  { id:97,  num:97,  fase:"Cuartos",     local:"W89", visitante:"W90",  fecha:"Jue 9 Jul",  hora:"14:00", estado:"pendiente", puedeIrAPenales:true },
  { id:98,  num:98,  fase:"Cuartos",     local:"W93", visitante:"W94",  fecha:"Vie 10 Jul", hora:"13:00", estado:"pendiente", puedeIrAPenales:true },
  { id:99,  num:99,  fase:"Cuartos",     local:"W91", visitante:"W92",  fecha:"Sáb 11 Jul", hora:"15:00", estado:"pendiente", puedeIrAPenales:true },
  { id:100, num:100, fase:"Cuartos",     local:"W95", visitante:"W96",  fecha:"Sáb 11 Jul", hora:"19:00", estado:"pendiente", puedeIrAPenales:true },

  // SEMIFINALES
  { id:101, num:101, fase:"Semifinales", local:"W97", visitante:"W98",  fecha:"Mar 14 Jul", hora:"13:00", estado:"pendiente", puedeIrAPenales:true },
  { id:102, num:102, fase:"Semifinales", local:"W99", visitante:"W100", fecha:"Mié 15 Jul", hora:"13:00", estado:"pendiente", puedeIrAPenales:true },

  // TERCER LUGAR Y FINAL
  { id:103, num:103, fase:"3er Lugar",   local:"L101", visitante:"L102", fecha:"Sáb 18 Jul", hora:"15:00", estado:"pendiente", puedeIrAPenales:true },
  { id:104, num:104, fase:"Final",       local:"W101", visitante:"W102", fecha:"Dom 19 Jul", hora:"13:00", estado:"pendiente", puedeIrAPenales:true },
];

// ── GRUPOS ────────────────────────────────────────────────
const GRUPOS = {
  A: ["México","Sudáfrica","Corea del Sur","UEFA Play-Off D"],
  B: ["Canadá","Catar","Suiza","UEFA Play-Off A"],
  C: ["Brasil","Marruecos","Haití","Escocia"],
  D: ["EEUU","Paraguay","Australia","UEFA Play-Off C"],
  E: ["Alemania","Curasao","Costa de Marfil","Ecuador"],
  F: ["Holanda","Japón","UEFA Play-Off B","Túnez"],
  G: ["Bélgica","Egipto","Irán","Nueva Zelanda"],
  H: ["España","Cabo Verde","Arabia Saudí","Uruguay"],
  I: ["Francia","Senegal","Fifa Play-Off 2","Noruega"],
  J: ["Argentina","Argelia","Austria","Jordania"],
  K: ["Portugal","Uzbekistán","Colombia","Fifa Play-Off 1"],
  L: ["Inglaterra","Croacia","Ghana","Panamá"],
};

// ── FUNCIONES DE DATOS ────────────────────────────────────
function obtenerPartidos() {
  const g = localStorage.getItem('partidos_mundial');
  return g ? JSON.parse(g) : JSON.parse(JSON.stringify(PARTIDOS));
}
function guardarPartidos(p) { localStorage.setItem('partidos_mundial', JSON.stringify(p)); }
function obtenerStats()     { const g = localStorage.getItem('stats_equipos'); return g ? JSON.parse(g) : JSON.parse(JSON.stringify(EQUIPOS_STATS)); }
function guardarStats(s)    { localStorage.setItem('stats_equipos', JSON.stringify(s)); }

// ── DEADLINE: cierre 9:30am Guatemala (UTC-6) = 15:30 UTC ─
function partidoEditable(p) {
  if (p.estado === 'finalizado') return false;
  const iso = FECHA_ISO[p.fecha];
  if (!iso) return true;
  return new Date() < new Date(iso + 'T15:30:00Z');
}
function textoDeadline(p) {
  return `Cierra ${p.fecha} 9:30am`;
}

// ── MOTOR DE PREDICCIÓN ESTADÍSTICA ──────────────────────
function predecirPartido(eqA, eqB) {
  const S  = obtenerStats();
  const A  = S[eqA] || { goles:1.2, tarjetas:1.5, offsides:1.4, ranking:50 };
  const B  = S[eqB] || { goles:1.2, tarjetas:1.5, offsides:1.4, ranking:50 };
  const f  = r => r<=5?1.25 : r<=15?1.12 : r<=30?1.00 : r<=50?0.88 : 0.78;
  const fA = f(A.ranking), fB = f(B.ranking);
  const gA = +(A.goles * fA * 0.9).toFixed(2);
  const gB = +(B.goles * fB * 0.9).toFixed(2);
  const mA = Math.round(gA), mB = Math.round(gB);

  // 4 sugerencias sutiles
  const empV = Math.max(mA, mB);
  const sugerencias = [
    { a: mA,    b: mB,    label: "Más probable" },
    { a: mA+1,  b: mB,    label: `Gana ${eqA.split(' ')[0]}` },
    { a: mA,    b: mB+1,  label: `Gana ${eqB.split(' ')[0]}` },
    { a: empV,  b: empV,  label: "Empate" },
  ];

  let probA = Math.min(72, Math.max(20, Math.round((gA / (gA + gB + 0.001)) * 100 * (fA / fB))));
  const probEmpate = 15;
  const probB = 100 - probA - probEmpate;

  const tarjAm = +((A.tarjetas + B.tarjetas) / 2).toFixed(1);
  const tarjRj = +(tarjAm * 0.15).toFixed(1);
  const offs   = +((A.offsides + B.offsides) / 2).toFixed(1);

  let exp = A.goles > B.goles
    ? `${eqA} tiene mayor promedio de goles (${A.goles} vs ${B.goles}).`
    : B.goles > A.goles
      ? `${eqB} tiene mayor promedio de goles (${B.goles} vs ${A.goles}).`
      : `Promedios de goles similares (${A.goles}). Partido equilibrado.`;

  if (A.ranking < B.ranking)
    exp += ` ${eqA} aventaja en FIFA (#${A.ranking} vs #${B.ranking}).`;
  else if (B.ranking < A.ranking)
    exp += ` ${eqB} aventaja en FIFA (#${B.ranking} vs #${A.ranking}).`;

  return { marcA:mA, marcB:mB, probA, probEmpate, probB,
           tarjAm, tarjRj, offs, explicacion:exp, sugerencias,
           rankA:A.ranking, rankB:B.ranking };
}

// ── CLASIFICACIÓN DE GRUPOS ───────────────────────────────
function calcularClasificacion(grupo) {
  const equipos = GRUPOS[grupo];
  if (!equipos) return [];
  const tabla = {};
  equipos.forEach(eq => { tabla[eq] = {equipo:eq,pj:0,pg:0,pe:0,pp:0,gf:0,gc:0,pts:0}; });
  obtenerPartidos()
    .filter(p => p.grupo === grupo && p.estado === 'finalizado')
    .forEach(p => {
      const L = tabla[p.local], V = tabla[p.visitante];
      if (!L || !V) return;
      L.pj++; V.pj++;
      L.gf += p.golesLocal||0;  L.gc += p.golesVisitante||0;
      V.gf += p.golesVisitante||0; V.gc += p.golesLocal||0;
      if      (p.golesLocal > p.golesVisitante) { L.pg++; L.pts+=3; V.pp++; }
      else if (p.golesLocal < p.golesVisitante) { V.pg++; V.pts+=3; L.pp++; }
      else                                       { L.pe++; V.pe++; L.pts++; V.pts++; }
    });
  return Object.values(tabla)
    .map(e => ({...e, dg: e.gf - e.gc}))
    .sort((a,b) => b.pts - a.pts || b.dg - a.dg || b.gf - a.gf);
}

// ── RESOLUCIÓN AUTOMÁTICA DE CLASIFICADOS ────────────────
// Soporta: "1A","2B","W74","L101", etc.
// Para partidos con penales: el clasificado es quien ganó en penales
function resolverEquipo(label) {
  if (!label) return label;
  const partidos = obtenerPartidos();

  // 1A, 2B, 3C → posición en grupo
  const mPos = label.match(/^([123])([A-L])$/);
  if (mPos) {
    const pos = parseInt(mPos[1]) - 1;
    const t   = calcularClasificacion(mPos[2]);
    if (t[pos] && t[pos].pj > 0) return t[pos].equipo;
    return label;
  }
  // Wxx → ganador del partido xx
  const mW = label.match(/^W(\d+)$/);
  if (mW) {
    const p = partidos.find(x => x.num === parseInt(mW[1]));
    if (!p || p.estado !== 'finalizado') return label;
    // Si hubo penales, gana quien tenga más en penales
    if (p.tienePenales) {
      return (p.penalesLocal||0) > (p.penalesVisitante||0) ? p.local : p.visitante;
    }
    return p.golesLocal > p.golesVisitante ? p.local : p.visitante;
  }
  // Lxx → perdedor del partido xx (tercer lugar)
  const mL = label.match(/^L(\d+)$/);
  if (mL) {
    const p = partidos.find(x => x.num === parseInt(mL[1]));
    if (!p || p.estado !== 'finalizado') return label;
    if (p.tienePenales) {
      return (p.penalesLocal||0) < (p.penalesVisitante||0) ? p.local : p.visitante;
    }
    return p.golesLocal < p.golesVisitante ? p.local : p.visitante;
  }
  // Si ya contiene "3A/B/…" u otro placeholder
  return label;
}

// ── PUNTOS QUINIELA ───────────────────────────────────────
// En eliminatoria con penales:
//   - La quiniela pide el marcador al final del tiempo reglamentario + prorroga
//   - NO se piden penales (demasiado difícil predecir)
//   - El ganador se valida contra quien clasificó realmente
function calcularPuntos(pred, partido) {
  if (!pred || partido.estado !== 'finalizado') return null;
  const ra = partido.golesLocal, rb = partido.golesVisitante;
  const pa = pred.golesLocal,    pb = pred.golesVisitante;
  if (pa === ra && pb === rb) return 5;
  // Para partidos con penales: el "ganador" en quiniela es quien clasifica
  let ganReal;
  if (partido.tienePenales) {
    ganReal = (partido.penalesLocal||0) > (partido.penalesVisitante||0) ? 'L' : 'V';
  } else {
    ganReal = ra>rb?'L':rb>ra?'V':'E';
  }
  const ganPred = pa>pb?'L':pb>pa?'V':'E';
  if (ganReal===ganPred && (ra-rb)===(pa-pb)) return 3;
  if (ganReal===ganPred) return 2;
  if ((ra+rb)===(pa+pb)) return 1;
  return 0;
}

// ── USUARIOS ──────────────────────────────────────────────
function obtenerUsuarios()     { return JSON.parse(localStorage.getItem('usuarios_mundial')||'[]'); }
function guardarUsuarios(u)    { localStorage.setItem('usuarios_mundial', JSON.stringify(u)); }
function obtenerPredicciones(u){ return JSON.parse(localStorage.getItem(`preds_${u}`)||'{}'); }
function guardarPredicciones(u,p){ localStorage.setItem(`preds_${u}`, JSON.stringify(p)); }

function calcularTablaPuntos() {
  const usuarios = obtenerUsuarios();
  const partidos = obtenerPartidos();
  return usuarios.filter(u => !u.esAdmin).map(u => {
    const preds = obtenerPredicciones(u.usuario);
    let total = 0;
    partidos.forEach(p => { if (preds[p.id]) total += calcularPuntos(preds[p.id], p) || 0; });
    return {...u, puntos:total};
  }).sort((a,b) => b.puntos - a.puntos);
}

// ── INIT ADMIN ────────────────────────────────────────────
(function(){
  const u = obtenerUsuarios();
  if (!u.find(x => x.usuario==='admin')) {
    u.push({ nombre:'Administrador', usuario:'admin', password:btoa('admin123'), esAdmin:true });
    guardarUsuarios(u);
  }
})();
